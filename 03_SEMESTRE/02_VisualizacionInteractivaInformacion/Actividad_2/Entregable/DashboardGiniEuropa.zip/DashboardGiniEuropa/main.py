def main():
    print("Iniciando DashBoard!")

if __name__ == "__main__":
    main()
