Hello :)

Please feel free to contribute!

This is a simple tutorial repository.

There are different ways to contribute:

 * Documentation
 * Code example improvement
 * Adding sections

Add issues if you want as placeholders for work you want to do, or as issues for others to work on.

https://github.com/elena/py2neo-quickstart/issues

---

### Current Work To Do:

 * The writing style can always be improved
 * Upgrade docs for latest release `py2neo` :  v2021.2 
 * "Solve" section could be improved, there's probably more features available now that when written.
 * OGM features could be discussed.
